#if defined(OPAQUE_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
$input a_indices
#endif
$input a_color0
#ifdef FANCY__ON
$input a_normal
#endif
$input a_position
$input a_texcoord0
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_clipPosition
$output v_color0
$output v_fog
$output v_light
$output v_texcoord0
$output v_worldPos
$output v_viewPos
#elif defined(ALPHA_TEST_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
$input a_indices
#endif
$input a_color0
#ifdef FANCY__ON
$input a_normal
#endif
$input a_position
$input a_texcoord0
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_clipPosition
$output v_color0
$output v_fog
$output v_light
$output v_texcoord0
$output v_worldPos
$output v_viewPos
#elif defined(TRANSPARENT_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
$input a_indices
#endif
$input a_color0
#ifdef FANCY__ON
$input a_normal
#endif
$input a_position
$input a_texcoord0
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_clipPosition
$output v_color0
$output v_fog
$output v_light
$output v_texcoord0
$output v_worldPos
$output v_viewPos
#elif defined(DEPTH_ONLY_OPAQUE_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
$input a_indices
#endif
#ifdef FANCY__ON
$input a_normal
#endif
$input a_position
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_clipPosition
$output v_color0
$output v_fog
$output v_light
$output v_texcoord0
$output v_worldPos
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
$input a_indices
#endif
#ifdef FANCY__ON
$input a_normal
#endif
$input a_position
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_clipPosition
$output v_color0
$output v_fog
$output v_light
$output v_texcoord0
$output v_worldPos
#endif

#include <bgfx_shader.sh>
#include <horror.sh>

#if defined(OPAQUE_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
uniform mat4 Bones[8];
#endif
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 OverlayColor;
uniform vec4 SubPixelOffset;
uniform vec4 TileLightColor;
uniform vec4 UVAnimation;

void main() {
#if defined(FANCY__OFF) && defined(INSTANCING__OFF)
    vec4 var_04231 = (u_model[0] * Bones[int(a_indices)]) * vec4(a_position, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__ON)
    vec3 var_dc61b = normalize((u_model[0] * Bones[int(a_indices)]) * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_89150;
    var_89150[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_89150[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_89150[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_89150[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__OFF)
    mat4 var_89150 = u_model[0] * Bones[int(a_indices)];
    vec3 var_dc61b = normalize(var_89150 * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#if defined(FANCY__ON) || defined(INSTANCING__ON)
    vec4 var_04231 = var_89150 * vec4(a_position, 1.0);
#endif
    mat4 var_83c3f = u_proj;
    vec4 var_67767 = var_83c3f[2];
    var_67767.x += SubPixelOffset.x;
    var_67767.y -= SubPixelOffset.y;
    mat4 var_cbf5d = u_proj;
    var_cbf5d[2] = var_67767;
    vec4 var_04ab5 = var_cbf5d * (u_view * vec4(var_04231.xyz, 1.0));
    vec4 var_27f6b = var_04ab5;
    v_clipPosition = var_04ab5;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_27f6b.z / FogControl.z) - FogControl.x) / (FogControl.y - FogControl.x), 0.0, 1.0));
#ifdef FANCY__OFF
    v_light = vec4(TileLightColor.xyz * (1.0 + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
#ifdef FANCY__ON
    v_light = vec4(TileLightColor.xyz * ((((((1.0 + var_dc61b.y) * 0.2750000059604644775390625) + ((var_dc61b.x * var_dc61b.x) * (-0.100000001490116119384765625))) + ((var_dc61b.z * var_dc61b.z) * 0.100000001490116119384765625)) + 0.449999988079071044921875) + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
    v_texcoord0 = UVAnimation.xy + (a_texcoord0 * UVAnimation.zw);
    v_worldPos = var_04231.xyz;
    vec4 ___cp1 = var_04ab5;
    gl_Position = ___cp1;
    v_viewPos = vec3(___cp1.xy / vec2(u_proj[0][0], u_proj[1][1]), ___cp1.w);
}

#elif defined(ALPHA_TEST_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
uniform mat4 Bones[8];
#endif
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 OverlayColor;
uniform vec4 SubPixelOffset;
uniform vec4 TileLightColor;
uniform vec4 UVAnimation;

void main() {
#if defined(FANCY__OFF) && defined(INSTANCING__OFF)
    vec4 var_04231 = (u_model[0] * Bones[int(a_indices)]) * vec4(a_position, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__ON)
    vec3 var_dc61b = normalize((u_model[0] * Bones[int(a_indices)]) * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_89150;
    var_89150[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_89150[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_89150[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_89150[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__OFF)
    mat4 var_89150 = u_model[0] * Bones[int(a_indices)];
    vec3 var_dc61b = normalize(var_89150 * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#if defined(FANCY__ON) || defined(INSTANCING__ON)
    vec4 var_04231 = var_89150 * vec4(a_position, 1.0);
#endif
    mat4 var_83c3f = u_proj;
    vec4 var_67767 = var_83c3f[2];
    var_67767.x += SubPixelOffset.x;
    var_67767.y -= SubPixelOffset.y;
    mat4 var_cbf5d = u_proj;
    var_cbf5d[2] = var_67767;
    vec4 var_04ab5 = var_cbf5d * (u_view * vec4(var_04231.xyz, 1.0));
    vec4 var_27f6b = var_04ab5;
    v_clipPosition = var_04ab5;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_27f6b.z / FogControl.z) - FogControl.x) / (FogControl.y - FogControl.x), 0.0, 1.0));
#ifdef FANCY__OFF
    v_light = vec4(TileLightColor.xyz * (1.0 + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
#ifdef FANCY__ON
    v_light = vec4(TileLightColor.xyz * ((((((1.0 + var_dc61b.y) * 0.2750000059604644775390625) + ((var_dc61b.x * var_dc61b.x) * (-0.100000001490116119384765625))) + ((var_dc61b.z * var_dc61b.z) * 0.100000001490116119384765625)) + 0.449999988079071044921875) + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
    v_texcoord0 = UVAnimation.xy + (a_texcoord0 * UVAnimation.zw);
    v_worldPos = var_04231.xyz;
    vec4 ___cp2 = var_04ab5;
    gl_Position = ___cp2;
    v_viewPos = vec3(___cp2.xy / vec2(u_proj[0][0], u_proj[1][1]), ___cp2.w);
}

#elif defined(TRANSPARENT_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
uniform mat4 Bones[8];
#endif
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 OverlayColor;
uniform vec4 SubPixelOffset;
uniform vec4 TileLightColor;
uniform vec4 UVAnimation;

void main() {
#if defined(FANCY__OFF) && defined(INSTANCING__OFF)
    vec4 var_04231 = (u_model[0] * Bones[int(a_indices)]) * vec4(a_position, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__ON)
    vec3 var_dc61b = normalize((u_model[0] * Bones[int(a_indices)]) * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_89150;
    var_89150[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_89150[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_89150[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_89150[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__OFF)
    mat4 var_89150 = u_model[0] * Bones[int(a_indices)];
    vec3 var_dc61b = normalize(var_89150 * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#if defined(FANCY__ON) || defined(INSTANCING__ON)
    vec4 var_04231 = var_89150 * vec4(a_position, 1.0);
#endif
    mat4 var_83c3f = u_proj;
    vec4 var_67767 = var_83c3f[2];
    var_67767.x += SubPixelOffset.x;
    var_67767.y -= SubPixelOffset.y;
    mat4 var_cbf5d = u_proj;
    var_cbf5d[2] = var_67767;
    vec4 var_04ab5 = var_cbf5d * (u_view * vec4(var_04231.xyz, 1.0));
    vec4 var_27f6b = var_04ab5;
    v_clipPosition = var_04ab5;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_27f6b.z / FogControl.z) - FogControl.x) / (FogControl.y - FogControl.x), 0.0, 1.0));
#ifdef FANCY__OFF
    v_light = vec4(TileLightColor.xyz * (1.0 + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
#ifdef FANCY__ON
    v_light = vec4(TileLightColor.xyz * ((((((1.0 + var_dc61b.y) * 0.2750000059604644775390625) + ((var_dc61b.x * var_dc61b.x) * (-0.100000001490116119384765625))) + ((var_dc61b.z * var_dc61b.z) * 0.100000001490116119384765625)) + 0.449999988079071044921875) + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
    v_texcoord0 = UVAnimation.xy + (a_texcoord0 * UVAnimation.zw);
    v_worldPos = var_04231.xyz;
    vec4 ___cp3 = var_04ab5;
    gl_Position = ___cp3;
    v_viewPos = vec3(___cp3.xy / vec2(u_proj[0][0], u_proj[1][1]), ___cp3.w);
}

#elif defined(DEPTH_ONLY_OPAQUE_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
uniform mat4 Bones[8];
#endif
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 OverlayColor;
uniform vec4 SubPixelOffset;
uniform vec4 TileLightColor;

void main() {
#if defined(FANCY__OFF) && defined(INSTANCING__OFF)
    vec4 var_04231 = (u_model[0] * Bones[int(a_indices)]) * vec4(a_position, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__ON)
    vec3 var_dc61b = normalize((u_model[0] * Bones[int(a_indices)]) * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_89150;
    var_89150[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_89150[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_89150[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_89150[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__OFF)
    mat4 var_89150 = u_model[0] * Bones[int(a_indices)];
    vec3 var_dc61b = normalize(var_89150 * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#if defined(FANCY__ON) || defined(INSTANCING__ON)
    vec4 var_04231 = var_89150 * vec4(a_position, 1.0);
#endif
    mat4 var_83c3f = u_proj;
    vec4 var_67767 = var_83c3f[2];
    var_67767.x += SubPixelOffset.x;
    var_67767.y -= SubPixelOffset.y;
    mat4 var_cbf5d = u_proj;
    var_cbf5d[2] = var_67767;
    vec4 var_04ab5 = var_cbf5d * (u_view * vec4(var_04231.xyz, 1.0));
    vec4 var_27f6b = var_04ab5;
    v_clipPosition = var_04ab5;
    v_color0 = vec4(0.0);
    v_fog = vec4(FogColor.xyz, clamp(((var_27f6b.z / FogControl.z) - FogControl.x) / (FogControl.y - FogControl.x), 0.0, 1.0));
#ifdef FANCY__OFF
    v_light = vec4(TileLightColor.xyz * (1.0 + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
#ifdef FANCY__ON
    v_light = vec4(TileLightColor.xyz * ((((((1.0 + var_dc61b.y) * 0.2750000059604644775390625) + ((var_dc61b.x * var_dc61b.x) * (-0.100000001490116119384765625))) + ((var_dc61b.z * var_dc61b.z) * 0.100000001490116119384765625)) + 0.449999988079071044921875) + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
    v_texcoord0 = vec2(0.0);
    v_worldPos = var_04231.xyz;
    gl_Position = var_04ab5;
}

#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
#if defined(FANCY__ON) || defined(INSTANCING__OFF)
uniform mat4 Bones[8];
#endif
uniform vec4 FogColor;
uniform vec4 FogControl;
uniform vec4 OverlayColor;
uniform vec4 SubPixelOffset;
uniform vec4 TileLightColor;

void main() {
#if defined(FANCY__OFF) && defined(INSTANCING__OFF)
    vec4 var_04231 = (u_model[0] * Bones[int(a_indices)]) * vec4(a_position, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__ON)
    vec3 var_dc61b = normalize((u_model[0] * Bones[int(a_indices)]) * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_89150;
    var_89150[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_89150[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_89150[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_89150[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
#endif
#if defined(FANCY__ON) && defined(INSTANCING__OFF)
    mat4 var_89150 = u_model[0] * Bones[int(a_indices)];
    vec3 var_dc61b = normalize(var_89150 * vec4(a_normal.xyz, 0.0)).xyz;
    var_dc61b.y *= TileLightColor.w;
#endif
#if defined(FANCY__ON) || defined(INSTANCING__ON)
    vec4 var_04231 = var_89150 * vec4(a_position, 1.0);
#endif
    mat4 var_83c3f = u_proj;
    vec4 var_67767 = var_83c3f[2];
    var_67767.x += SubPixelOffset.x;
    var_67767.y -= SubPixelOffset.y;
    mat4 var_cbf5d = u_proj;
    var_cbf5d[2] = var_67767;
    vec4 var_04ab5 = var_cbf5d * (u_view * vec4(var_04231.xyz, 1.0));
    vec4 var_27f6b = var_04ab5;
    v_clipPosition = var_04ab5;
    v_color0 = vec4(0.0);
    v_fog = vec4(FogColor.xyz, clamp(((var_27f6b.z / FogControl.z) - FogControl.x) / (FogControl.y - FogControl.x), 0.0, 1.0));
#ifdef FANCY__OFF
    v_light = vec4(TileLightColor.xyz * (1.0 + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
#ifdef FANCY__ON
    v_light = vec4(TileLightColor.xyz * ((((((1.0 + var_dc61b.y) * 0.2750000059604644775390625) + ((var_dc61b.x * var_dc61b.x) * (-0.100000001490116119384765625))) + ((var_dc61b.z * var_dc61b.z) * 0.100000001490116119384765625)) + 0.449999988079071044921875) + (OverlayColor.w * 0.3499999940395355224609375)), 1.0);
#endif
    v_texcoord0 = vec2(0.0);
    v_worldPos = var_04231.xyz;
    gl_Position = var_04ab5;
}

#endif
