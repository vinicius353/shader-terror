#if defined(OPAQUE_PASS)
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_viewPos
#elif defined(ALPHA_TEST_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_worldPos
$input v_viewPos
#elif defined(TRANSPARENT_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_worldPos
$input v_viewPos
#elif defined(DEPTH_ONLY_OPAQUE_PASS)
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
#endif

#include <bgfx_shader.sh>
#define H_AMBIENT_OVERRIDE 0.10
#include <horror.sh>

#if defined(OPAQUE_PASS)
#ifdef MASKED_MULTITEXTURE__ON
SAMPLER2D(s_MatTexture1, s_MatTexture1_REG);
#endif
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
#ifndef CHANGE_COLOR__OFF
uniform vec4 ChangeColor;
#endif
uniform vec4 ColorBased;
uniform vec4 MatColor;
#ifdef CHANGE_COLOR__MULTI
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
#if defined(MASKED_MULTITEXTURE__OFF) && !defined(CHANGE_COLOR__OFF)
    vec4 var_98b25 = MatColor * texture2D(s_MatTexture, v_texcoord0);
#endif
#if defined(CHANGE_COLOR__OFF) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_1591d = MatColor * texture2D(s_MatTexture, v_texcoord0);
#endif
#ifdef MASKED_MULTITEXTURE__ON
    vec4 var_7fef3 = texture2D(s_MatTexture1, v_texcoord0);
    vec4 var_0b7d3 = var_7fef3;
#endif
#if defined(CHANGE_COLOR__ON) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_1591d = var_98b25;
#endif
#if defined(MASKED_MULTITEXTURE__ON) && !defined(CHANGE_COLOR__OFF)
    vec4 var_98b25 = mix(var_7fef3, MatColor * texture2D(s_MatTexture, v_texcoord0), vec4(float((((var_0b7d3.x + var_0b7d3.y) + var_0b7d3.z) * (1.0 - var_0b7d3.w)) > 0.0)));
#endif
#if defined(CHANGE_COLOR__OFF) && defined(MASKED_MULTITEXTURE__ON)
    vec4 var_1591d = mix(var_7fef3, MatColor * texture2D(s_MatTexture, v_texcoord0), vec4(float((((var_0b7d3.x + var_0b7d3.y) + var_0b7d3.z) * (1.0 - var_0b7d3.w)) > 0.0)));
#endif
#ifdef CHANGE_COLOR__MULTI
    vec2 var_459de = var_98b25.xy;
    vec3 var_1099e = mix((var_98b25.xxx * ChangeColor.xyz).xyz, var_98b25.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_459de.y)));
    vec4 var_1591d = vec4(var_1099e.x, var_1099e.y, var_1099e.z, var_98b25.w);
#endif
#if defined(CHANGE_COLOR__ON) && defined(MASKED_MULTITEXTURE__ON)
    vec4 var_1591d = var_98b25;
#endif
#ifdef CHANGE_COLOR__ON
    vec4 var_8a135 = ChangeColor;
    vec3 var_fba6e = mix(var_98b25.xyz, var_98b25.xyz * ChangeColor.xyz, vec3(var_1591d.w));
    var_1591d = vec4(var_fba6e.x, var_fba6e.y, var_fba6e.z, var_98b25.w);
    var_1591d.w *= var_8a135.w;
#endif
    var_1591d.w = max(0.0, var_1591d.w);
#ifndef EMISSIVE__OFF
    vec3 var_5d005 = mix((var_1591d.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w));
#endif
#ifdef EMISSIVE__OFF
    vec3 var_5d005 = mix((var_1591d.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
    vec4 var_b9108 = vec4(var_5d005.x, var_5d005.y, var_5d005.z, var_1591d.w);
#ifndef EMISSIVE__OFF
    float var_4c6fb = var_b9108.w;
    vec3 var_1325b = var_5d005.xyz * mix(vec4(1.0), v_light, vec4(var_4c6fb)).xyz;
    vec4 var_b626b = vec4(var_1325b.x, var_1325b.y, var_1325b.z, var_1591d.w);
    var_b9108 = var_b626b;
    vec4 var_ab9d7 = var_b626b;
    vec4 var_e8775 = vec4(var_1325b, var_ab9d7.w);
#endif
#ifdef EMISSIVE__OFF
    vec4 var_e8775 = vec4(var_5d005, var_b9108.w);
#endif
    vec4 var_6ca24 = v_fog;
    vec3 var_42372 = mix(var_e8775.xyz, v_fog.xyz, vec3(var_6ca24.w));
    vec4 var_73fd7 = vec4(var_42372.x, var_42372.y, var_42372.z, var_e8775.w);
    var_73fd7.w = 1.0;
    {
        vec4 ___fc1 = var_73fd7;
        ___fc1.xyz = horrorApply(___fc1.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc1;
    }
}

#elif defined(ALPHA_TEST_PASS)
float var_33fae;
#ifdef MASKED_MULTITEXTURE__ON
SAMPLER2D(s_MatTexture1, s_MatTexture1_REG);
#endif
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
#if !defined(CHANGE_COLOR__OFF) || !defined(EMISSIVE__OFF)
uniform vec4 ActorFPEpsilon;
#endif
#ifndef CHANGE_COLOR__OFF
uniform vec4 ChangeColor;
#endif
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
uniform vec4 MatColor;
#ifdef CHANGE_COLOR__MULTI
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;
uniform vec4 TintedAlphaTestEnabled;
uniform vec4 UseAlphaRewrite;

void main() {
#ifdef EMISSIVE__EMISSIVE
    vec4 var_a25d1 = texture2D(s_MatTexture, v_texcoord0);
#endif
#if defined(EMISSIVE__EMISSIVE) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_d9ac1 = MatColor * var_a25d1;
#endif
#ifdef MASKED_MULTITEXTURE__ON
    vec4 var_174cf = texture2D(s_MatTexture1, v_texcoord0);
    vec4 var_f3ddc = var_174cf;
#endif
#if defined(EMISSIVE__EMISSIVE) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_c81f0 = var_d9ac1;
#endif
#if defined(EMISSIVE__EMISSIVE) && defined(MASKED_MULTITEXTURE__ON)
    vec4 var_d9ac1 = mix(var_174cf, MatColor * var_a25d1, vec4(float((((var_f3ddc.x + var_f3ddc.y) + var_f3ddc.z) * (1.0 - var_f3ddc.w)) > 0.0)));
    vec4 var_c81f0 = var_d9ac1;
#endif
#if defined(MASKED_MULTITEXTURE__OFF) && !defined(EMISSIVE__EMISSIVE)
    vec4 var_c81f0 = MatColor * texture2D(s_MatTexture, v_texcoord0);
#endif
#if defined(MASKED_MULTITEXTURE__ON) && !defined(EMISSIVE__EMISSIVE)
    vec4 var_c81f0 = mix(var_174cf, MatColor * texture2D(s_MatTexture, v_texcoord0), vec4(float((((var_f3ddc.x + var_f3ddc.y) + var_f3ddc.z) * (1.0 - var_f3ddc.w)) > 0.0)));
#endif
#ifdef EMISSIVE__EMISSIVE_ONLY
    float var_a8620 = mix(var_c81f0.w, var_c81f0.w * OverlayColor.w, TintedAlphaTestEnabled.x);
    bool var_e7bf9 = var_a8620 < ActorFPEpsilon.x;
    bool var_bd07c;
    if (!var_e7bf9)
    {
        var_bd07c = var_a8620 > (1.0 - ActorFPEpsilon.x);
    }
    else
    {
        var_bd07c = var_e7bf9;
    }
#endif
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_e194d;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_e194d = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_e194d = false;
    }
#ifdef EMISSIVE__EMISSIVE
    if (var_e194d || (dot(vec4(var_d9ac1.xyz, mix(var_c81f0.w, var_c81f0.w * OverlayColor.w, TintedAlphaTestEnabled.x)), vec4(1.0)) < ActorFPEpsilon.x))
#endif
#ifdef EMISSIVE__EMISSIVE_ONLY
    if (var_e194d || var_bd07c)
#endif
#if defined(EMISSIVE__OFF) && !defined(CHANGE_COLOR__OFF)
    if (var_e194d || (mix(var_c81f0.w, var_c81f0.w * OverlayColor.w, TintedAlphaTestEnabled.x) < ActorFPEpsilon.x))
#endif
#if defined(CHANGE_COLOR__OFF) && defined(EMISSIVE__OFF)
    if (var_e194d || (mix(var_c81f0.w, var_c81f0.w * OverlayColor.w, TintedAlphaTestEnabled.x) < 0.5))
#endif
    {
        discard;
    }
#ifdef CHANGE_COLOR__MULTI
    vec2 var_459de = var_c81f0.xy;
    vec3 var_1099e = mix((var_c81f0.xxx * ChangeColor.xyz).xyz, var_c81f0.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_459de.y)));
    vec4 var_776bd = vec4(var_1099e.x, var_1099e.y, var_1099e.z, var_c81f0.w);
#endif
#ifndef CHANGE_COLOR__MULTI
    vec4 var_776bd = var_c81f0;
#endif
#ifdef CHANGE_COLOR__ON
    vec4 var_8a135 = ChangeColor;
    vec3 var_fba6e = mix(var_c81f0.xyz, var_c81f0.xyz * ChangeColor.xyz, vec3(var_776bd.w));
    var_776bd = vec4(var_fba6e.x, var_fba6e.y, var_fba6e.z, var_c81f0.w);
    var_776bd.w *= var_8a135.w;
#endif
    var_776bd.w = max(UseAlphaRewrite.x, var_776bd.w);
    var_c81f0 = var_776bd;
#ifndef EMISSIVE__OFF
    vec3 var_10fed = mix((var_776bd.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w));
#endif
#ifdef EMISSIVE__OFF
    vec3 var_10fed = mix((var_776bd.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
    vec4 var_cd387 = vec4(var_10fed.x, var_10fed.y, var_10fed.z, var_776bd.w);
#ifndef EMISSIVE__OFF
    float var_4c6fb = var_cd387.w;
    vec3 var_cf2dd = var_10fed.xyz * mix(vec4(1.0), v_light, vec4(var_4c6fb)).xyz;
    vec4 var_b626b = vec4(var_cf2dd.x, var_cf2dd.y, var_cf2dd.z, var_776bd.w);
    var_cd387 = var_b626b;
    vec4 var_95ebc = var_b626b;
#endif
    vec4 var_10e64 = v_fog;
#ifndef EMISSIVE__OFF
    {
        vec4 ___fc2 = vec4(mix(vec4(var_cf2dd, var_95ebc.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_95ebc.w);
        ___fc2.xyz = horrorApply(___fc2.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc2;
    }
#endif
#ifdef EMISSIVE__OFF
    {
        vec4 ___fc3 = vec4(mix(vec4(var_10fed, var_cd387.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_cd387.w);
        ___fc3.xyz = horrorApply(___fc3.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc3;
    }
#endif
}

#elif defined(TRANSPARENT_PASS)
float var_33fae;
#ifdef MASKED_MULTITEXTURE__ON
SAMPLER2D(s_MatTexture1, s_MatTexture1_REG);
#endif
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
#ifndef CHANGE_COLOR__OFF
uniform vec4 ChangeColor;
#endif
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
uniform vec4 HudOpacity;
uniform vec4 MatColor;
#ifdef CHANGE_COLOR__MULTI
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
#if defined(MASKED_MULTITEXTURE__OFF) && !defined(CHANGE_COLOR__OFF)
    vec4 var_98b25 = MatColor * texture2D(s_MatTexture, v_texcoord0);
#endif
#if defined(CHANGE_COLOR__OFF) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_9bc35 = MatColor * texture2D(s_MatTexture, v_texcoord0);
#endif
#ifdef MASKED_MULTITEXTURE__ON
    vec4 var_7fef3 = texture2D(s_MatTexture1, v_texcoord0);
    vec4 var_0b7d3 = var_7fef3;
#endif
#if defined(CHANGE_COLOR__ON) && defined(MASKED_MULTITEXTURE__OFF)
    vec4 var_9bc35 = var_98b25;
#endif
#if defined(MASKED_MULTITEXTURE__ON) && !defined(CHANGE_COLOR__OFF)
    vec4 var_98b25 = mix(var_7fef3, MatColor * texture2D(s_MatTexture, v_texcoord0), vec4(float((((var_0b7d3.x + var_0b7d3.y) + var_0b7d3.z) * (1.0 - var_0b7d3.w)) > 0.0)));
#endif
#if defined(CHANGE_COLOR__OFF) && defined(MASKED_MULTITEXTURE__ON)
    vec4 var_9bc35 = mix(var_7fef3, MatColor * texture2D(s_MatTexture, v_texcoord0), vec4(float((((var_0b7d3.x + var_0b7d3.y) + var_0b7d3.z) * (1.0 - var_0b7d3.w)) > 0.0)));
#endif
#ifdef CHANGE_COLOR__MULTI
    vec2 var_459de = var_98b25.xy;
    vec3 var_1099e = mix((var_98b25.xxx * ChangeColor.xyz).xyz, var_98b25.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_459de.y)));
    vec4 var_9bc35 = vec4(var_1099e.x, var_1099e.y, var_1099e.z, var_98b25.w);
#endif
#if defined(CHANGE_COLOR__ON) && defined(MASKED_MULTITEXTURE__ON)
    vec4 var_9bc35 = var_98b25;
#endif
#ifdef CHANGE_COLOR__ON
    vec4 var_8a135 = ChangeColor;
    vec3 var_fba6e = mix(var_98b25.xyz, var_98b25.xyz * ChangeColor.xyz, vec3(var_9bc35.w));
    var_9bc35 = vec4(var_fba6e.x, var_fba6e.y, var_fba6e.z, var_98b25.w);
    var_9bc35.w *= var_8a135.w;
#endif
    var_9bc35.w = max(0.0, var_9bc35.w);
#ifndef EMISSIVE__OFF
    vec3 var_6f37e = mix((var_9bc35.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w));
#endif
#ifdef EMISSIVE__OFF
    vec3 var_d8325 = mix((var_9bc35.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
#ifdef EMISSIVE__OFF
    vec4 var_e308a = vec4(var_d8325.x, var_d8325.y, var_d8325.z, var_9bc35.w);
#endif
#ifndef EMISSIVE__OFF
    vec4 var_3b10d = vec4(var_6f37e.x, var_6f37e.y, var_6f37e.z, var_9bc35.w);
    float var_4c6fb = var_3b10d.w;
    vec3 var_eec31 = var_6f37e.xyz * mix(vec4(1.0), v_light, vec4(var_4c6fb)).xyz;
    vec4 var_b626b = vec4(var_eec31.x, var_eec31.y, var_eec31.z, var_9bc35.w);
    var_3b10d = var_b626b;
    vec4 var_e308a = var_b626b;
#endif
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_218e3;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_218e3 = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_218e3 = false;
    }
    float var_8785e = (var_e308a.w * HudOpacity.x) * (var_218e3 ? 0.0 : 1.0);
    vec4 var_9efa6 = v_fog;
#ifndef EMISSIVE__OFF
    {
        vec4 ___fc4 = vec4(mix(vec4(var_eec31, var_8785e).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_8785e);
        ___fc4.xyz = horrorApply(___fc4.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc4;
    }
#endif
#ifdef EMISSIVE__OFF
    {
        vec4 ___fc5 = vec4(mix(vec4(var_d8325, var_8785e).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_8785e);
        ___fc5.xyz = horrorApply(___fc5.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc5;
    }
#endif
}

#elif defined(DEPTH_ONLY_OPAQUE_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#endif
