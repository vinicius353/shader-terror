#if defined(OPAQUE_PASS)
$input v_color0
$input v_fog
$input v_light
$input v_viewPos
#elif defined(ALPHA_TEST_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_worldPos
$input v_viewPos
#elif defined(TRANSPARENT_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_worldPos
$input v_viewPos
#elif defined(DEPTH_ONLY_OPAQUE_PASS)
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
#endif

#include <bgfx_shader.sh>
#define H_AMBIENT_OVERRIDE 0.35
#include <horror.sh>

#if defined(OPAQUE_PASS)
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_fef14 = v_color0;
    vec3 var_f90fa = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_d683b = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_d683b.xy;
    vec3 var_f90fa = mix(mix((var_d683b.xxx * ChangeColor.xyz).xyz, var_d683b.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
    vec4 var_1aaf3 = vec4(var_f90fa.x, var_f90fa.y, var_f90fa.z, vec4(1.0).w);
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_570ea = mix(mix(var_1aaf3, var_1aaf3 * ChangeColor, vec4(var_fef14.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_3849e = vec4(var_570ea.x, var_570ea.y, var_570ea.z, vec4(1.0).w);
#endif
    vec4 var_10e64 = v_fog;
#ifdef MULTI_COLOR_TINT__OFF
    {
        vec4 ___fc1 = vec4(mix(vec4(var_570ea, var_3849e.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_3849e.w);
        ___fc1.xyz = horrorApply(___fc1.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc1;
    }
#endif
#ifdef MULTI_COLOR_TINT__ON
    {
        vec4 ___fc2 = vec4(mix(vec4(var_f90fa, var_1aaf3.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_1aaf3.w);
        ___fc2.xyz = horrorApply(___fc2.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc2;
    }
#endif
}

#elif defined(ALPHA_TEST_PASS)
float var_33fae;
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_fef14 = v_color0;
    vec3 var_05ab4 = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_d683b = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_d683b.xy;
    vec3 var_df371 = mix(mix((var_d683b.xxx * ChangeColor.xyz).xyz, var_d683b.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_1eced = vec4(var_df371.x, var_df371.y, var_df371.z, vec4(1.0).w);
#endif
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_90a94 = vec4(var_05ab4.x, var_05ab4.y, var_05ab4.z, vec4(1.0).w);
    vec3 var_df371 = mix(mix(var_90a94, var_90a94 * ChangeColor, vec4(var_fef14.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_1eced = vec4(var_df371.x, var_df371.y, var_df371.z, vec4(1.0).w);
#endif
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_ab7ce;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_ab7ce = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_ab7ce = false;
    }
    if (var_ab7ce || (var_1eced.w < 0.5))
    {
        discard;
    }
    vec4 var_eb888 = v_fog;
    {
        vec4 ___fc3 = vec4(mix(vec4(var_df371, var_1eced.w).xyz, v_fog.xyz, vec3(var_eb888.w)), var_1eced.w);
        ___fc3.xyz = horrorApply(___fc3.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc3;
    }
}

#elif defined(TRANSPARENT_PASS)
float var_33fae;
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_fef14 = v_color0;
    vec3 var_05ab4 = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_d683b = mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_d683b.xy;
    vec3 var_74477 = mix(mix((var_d683b.xxx * ChangeColor.xyz).xyz, var_d683b.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_eb836 = vec4(var_74477.x, var_74477.y, var_74477.z, vec4(1.0).w);
#endif
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_90a94 = vec4(var_05ab4.x, var_05ab4.y, var_05ab4.z, vec4(1.0).w);
    vec3 var_1c509 = mix(mix(var_90a94, var_90a94 * ChangeColor, vec4(var_fef14.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_eb836 = vec4(var_1c509.x, var_1c509.y, var_1c509.z, vec4(1.0).w);
#endif
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_c20f0;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_c20f0 = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_c20f0 = false;
    }
    float var_17bd7 = var_eb836.w * (var_c20f0 ? 0.0 : 1.0);
    vec4 var_9efa6 = v_fog;
#ifdef MULTI_COLOR_TINT__OFF
    {
        vec4 ___fc4 = vec4(mix(vec4(var_1c509, var_17bd7).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_17bd7);
        ___fc4.xyz = horrorApply(___fc4.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc4;
    }
#endif
#ifdef MULTI_COLOR_TINT__ON
    {
        vec4 ___fc5 = vec4(mix(vec4(var_74477, var_17bd7).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_17bd7);
        ___fc5.xyz = horrorApply(___fc5.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc5;
    }
#endif
}

#elif defined(DEPTH_ONLY_OPAQUE_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#endif
