#if defined(OPAQUE_PASS)
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_viewPos
#elif defined(ALPHA_TEST_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_worldPos
$input v_viewPos
#elif defined(TRANSPARENT_PASS)
$input v_clipPosition
$input v_color0
$input v_fog
$input v_light
$input v_texcoord0
$input v_worldPos
$input v_viewPos
#elif defined(DEPTH_ONLY_OPAQUE_PASS)
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
#endif

#include <bgfx_shader.sh>
#define H_AMBIENT_OVERRIDE 0.35
#include <horror.sh>

#if defined(OPAQUE_PASS)
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
uniform vec4 AlphaMaskedTint;
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
uniform vec4 MatColor;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
    vec4 var_f5beb = v_color0;
    vec4 var_1bee0 = texture2D(s_MatTexture, v_texcoord0);
    if (AlphaMaskedTint.x != 0.0)
    {
        vec3 var_5e4d7 = mix(var_1bee0.xyz, var_1bee0.xyz * v_color0.xyz, vec3(var_1bee0.w)).xyz * var_f5beb.w;
        var_1bee0 = vec4(var_5e4d7.x, var_5e4d7.y, var_5e4d7.z, var_1bee0.w);
        var_1bee0.w = 1.0;
    }
    else
    {
        vec3 var_55928 = var_1bee0.xyz * v_color0.xyz;
        var_1bee0 = vec4(var_55928.x, var_55928.y, var_55928.z, var_1bee0.w);
    }
    vec4 var_74395 = var_1bee0;
    vec4 var_41ee0 = var_74395 * MatColor;
    var_1bee0 = var_41ee0;
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_447d4 = var_41ee0.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_61abf = var_41ee0.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_61abf.xy;
    vec3 var_447d4 = mix(mix((var_61abf.xxx * ChangeColor.xyz).xyz, var_61abf.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
    vec4 var_2db59 = vec4(var_447d4.x, var_447d4.y, var_447d4.z, var_41ee0.w);
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_b1be3 = mix(mix(var_2db59, var_2db59 * ChangeColor, vec4(var_f5beb.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_1146b = vec4(var_b1be3.x, var_b1be3.y, var_b1be3.z, var_41ee0.w);
#endif
    vec4 var_10e64 = v_fog;
#ifdef MULTI_COLOR_TINT__OFF
    {
        vec4 ___fc1 = vec4(mix(vec4(var_b1be3, var_1146b.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_1146b.w);
        ___fc1.xyz = horrorApply(___fc1.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc1;
    }
#endif
#ifdef MULTI_COLOR_TINT__ON
    {
        vec4 ___fc2 = vec4(mix(vec4(var_447d4, var_2db59.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_2db59.w);
        ___fc2.xyz = horrorApply(___fc2.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc2;
    }
#endif
}

#elif defined(ALPHA_TEST_PASS)
float var_33fae;
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
uniform vec4 AlphaMaskedTint;
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
uniform vec4 MatColor;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
    vec4 var_f5beb = v_color0;
    vec4 var_1bee0 = texture2D(s_MatTexture, v_texcoord0);
    if (AlphaMaskedTint.x != 0.0)
    {
        vec3 var_5e4d7 = mix(var_1bee0.xyz, var_1bee0.xyz * v_color0.xyz, vec3(var_1bee0.w)).xyz * var_f5beb.w;
        var_1bee0 = vec4(var_5e4d7.x, var_5e4d7.y, var_5e4d7.z, var_1bee0.w);
        var_1bee0.w = 1.0;
    }
    else
    {
        vec3 var_55928 = var_1bee0.xyz * v_color0.xyz;
        var_1bee0 = vec4(var_55928.x, var_55928.y, var_55928.z, var_1bee0.w);
    }
    vec4 var_74395 = var_1bee0;
    vec4 var_30e9e = var_74395 * MatColor;
    var_1bee0 = var_30e9e;
    vec4 var_a9bff = var_30e9e;
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_ab7ce;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_ab7ce = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_ab7ce = false;
    }
    if (var_ab7ce || (var_a9bff.w < 0.5))
    {
        discard;
    }
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_447d4 = var_30e9e.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_61abf = var_30e9e.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_61abf.xy;
    vec3 var_447d4 = mix(mix((var_61abf.xxx * ChangeColor.xyz).xyz, var_61abf.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
#endif
    vec4 var_2db59 = vec4(var_447d4.x, var_447d4.y, var_447d4.z, var_30e9e.w);
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_b1be3 = mix(mix(var_2db59, var_2db59 * ChangeColor, vec4(var_f5beb.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_1146b = vec4(var_b1be3.x, var_b1be3.y, var_b1be3.z, var_30e9e.w);
#endif
    vec4 var_10e64 = v_fog;
#ifdef MULTI_COLOR_TINT__OFF
    {
        vec4 ___fc3 = vec4(mix(vec4(var_b1be3, var_1146b.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_1146b.w);
        ___fc3.xyz = horrorApply(___fc3.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc3;
    }
#endif
#ifdef MULTI_COLOR_TINT__ON
    {
        vec4 ___fc4 = vec4(mix(vec4(var_447d4, var_2db59.w).xyz, v_fog.xyz, vec3(var_10e64.w)), var_2db59.w);
        ___fc4.xyz = horrorApply(___fc4.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc4;
    }
#endif
}

#elif defined(TRANSPARENT_PASS)
float var_33fae;
SAMPLER2D(s_MatTexture, s_MatTexture_REG);
uniform vec4 AlphaMaskedTint;
uniform vec4 ChangeColor;
uniform vec4 ColorBased;
uniform vec4 DitherParams2[3];
uniform vec4 DitherParams;
uniform vec4 DitheringEnabledToggle;
uniform vec4 MatColor;
#ifdef MULTI_COLOR_TINT__ON
uniform vec4 MultiplicativeTintColor;
#endif
uniform vec4 OverlayColor;

void main() {
    vec4 var_f5beb = v_color0;
    vec4 var_1bee0 = texture2D(s_MatTexture, v_texcoord0);
    if (AlphaMaskedTint.x != 0.0)
    {
        vec3 var_5e4d7 = mix(var_1bee0.xyz, var_1bee0.xyz * v_color0.xyz, vec3(var_1bee0.w)).xyz * var_f5beb.w;
        var_1bee0 = vec4(var_5e4d7.x, var_5e4d7.y, var_5e4d7.z, var_1bee0.w);
        var_1bee0.w = 1.0;
    }
    else
    {
        vec3 var_55928 = var_1bee0.xyz * v_color0.xyz;
        var_1bee0 = vec4(var_55928.x, var_55928.y, var_55928.z, var_1bee0.w);
    }
    vec4 var_74395 = var_1bee0;
    vec4 var_0d9b4 = var_74395 * MatColor;
    var_1bee0 = var_0d9b4;
#ifdef MULTI_COLOR_TINT__OFF
    vec3 var_2ce32 = var_0d9b4.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
#endif
#ifdef MULTI_COLOR_TINT__ON
    vec3 var_61abf = var_0d9b4.xyz * mix(vec3(1.0), v_color0.xyz, vec3(ColorBased.x));
    vec2 var_533c7 = var_61abf.xy;
    vec3 var_66e1f = mix(mix((var_61abf.xxx * ChangeColor.xyz).xyz, var_61abf.yyy * MultiplicativeTintColor.xyz, vec3(ceil(var_533c7.y))).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_6eb8b = vec4(var_66e1f.x, var_66e1f.y, var_66e1f.z, var_0d9b4.w);
#endif
#ifdef MULTI_COLOR_TINT__OFF
    vec4 var_8990b = vec4(var_2ce32.x, var_2ce32.y, var_2ce32.z, var_0d9b4.w);
    vec3 var_96393 = mix(mix(var_8990b, var_8990b * ChangeColor, vec4(var_f5beb.w)).xyz, OverlayColor.xyz, vec3(OverlayColor.w)).xyz * v_light.xyz;
    vec4 var_6eb8b = vec4(var_96393.x, var_96393.y, var_96393.z, var_0d9b4.w);
#endif
    vec2 var_7c9c5 = DitherParams2[0].xy;
    bool var_c20f0;
    if (DitheringEnabledToggle.x != 0.0)
    {
        mat4 var_4971e = u_view;
        vec4 var_d36cf = v_clipPosition;
        vec2 var_886c2 = floor(((((v_clipPosition.xyz / vec3(var_d36cf.w)).xy * 0.5) + vec2(0.5)) * DitherParams.xy) / vec2(DitherParams2[0].z)) * DitherParams2[0].z;
        vec2 var_f4989 = floor(var_886c2 * 0.25);
        vec2 var_85686 = floor(var_886c2 * 0.5);
        vec2 var_09c49 = floor(var_886c2);
        var_c20f0 = smoothstep(var_7c9c5.x, var_7c9c5.y, dot(-normalize(vec4(var_4971e[0].z, var_4971e[1].z, var_4971e[2].z, var_33fae).xyz), v_worldPos - (u_invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz)) <= (((((((fract((var_f4989.x * 0.5) + ((var_f4989.y * var_f4989.y) * 0.75)) * 0.25) + fract((var_85686.x * 0.5) + ((var_85686.y * var_85686.y) * 0.75))) * 0.25) + fract((var_09c49.x * 0.5) + ((var_09c49.y * var_09c49.y) * 0.75))) * 64.0) + 0.5) * 0.015625);
    }
    else
    {
        var_c20f0 = false;
    }
    float var_17bd7 = var_6eb8b.w * (var_c20f0 ? 0.0 : 1.0);
    vec4 var_9efa6 = v_fog;
#ifdef MULTI_COLOR_TINT__OFF
    {
        vec4 ___fc5 = vec4(mix(vec4(var_96393, var_17bd7).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_17bd7);
        ___fc5.xyz = horrorApply(___fc5.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc5;
    }
#endif
#ifdef MULTI_COLOR_TINT__ON
    {
        vec4 ___fc6 = vec4(mix(vec4(var_66e1f, var_17bd7).xyz, v_fog.xyz, vec3(var_9efa6.w)), var_17bd7);
        ___fc6.xyz = horrorApply(___fc6.xyz, v_fog.xyz, v_viewPos, v_light.xyz);
        gl_FragColor = ___fc6;
    }
#endif
}

#elif defined(DEPTH_ONLY_OPAQUE_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)

void main() {
    gl_FragColor = vec4(0.0);
}

#endif
