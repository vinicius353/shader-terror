#if defined(DEPTH_ONLY_OPAQUE_PASS)
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
$input v_texcoord0
#else
$input v_color0, v_fog, v_lightmapUV, v_texcoord0, v_ditheringAndMaskTinting, v_viewPos
#endif

#include <bgfx_shader.sh>

// =====================================================
//  AJUSTES DO SHADER DE TERROR (edite so estes numeros)
// =====================================================
#define AMBIENT        0.10   // luz geral (0 = breu total, 0.3 = penumbra)
#define BEAM_POWER     1.70   // forca da lanterna
#define BEAM_RANGE     26.0   // alcance da lanterna em blocos
#define CONE_INNER     0.16   // abertura do centro do cone (maior = mais largo)
#define CONE_OUTER     0.52   // borda suave do cone
#define SATURATION     0.55   // 1 = cores normais, 0 = preto e branco
#define FOG_DARK       vec3(0.008, 0.010, 0.014)  // cor da neblina
// =====================================================

#if defined(DEPTH_ONLY_OPAQUE_PASS)

void main() {
    gl_FragColor = vec4_splat(0.0);
}

#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)

SAMPLER2D(s_MatTexture, s_MatTexture_REG);

void main() {
    vec4 d = texture2D(s_MatTexture, v_texcoord0);
    if (d.w < 0.5) {
        discard;
    }
    gl_FragColor = vec4_splat(0.0);
}

#else

SAMPLER2D(s_MatTexture, s_MatTexture_REG);
SAMPLER2D(s_LightMapTexture, s_LightMapTexture_REG);
#ifdef SEASONS__ON
SAMPLER2D(s_SeasonsTexture, s_SeasonsTexture_REG);
#endif

uniform vec4 FogColor;
uniform vec4 ViewPositionAndTime;

void main() {
    vec4 diffuse = texture2D(s_MatTexture, v_texcoord0);

#if defined(ALPHA_TEST_PASS)
    if (diffuse.w < 0.5) {
        discard;
    }
#endif

#ifdef SEASONS__ON
    vec3 seasonTint = mix(vec3_splat(1.0), texture2D(s_SeasonsTexture, v_color0.xy).xyz * 2.0, v_color0.z);
    diffuse = vec4(diffuse.xyz * seasonTint * v_color0.w, 1.0);
#else
#if defined(ALPHA_TEST_PASS)
    diffuse.xyz *= v_color0.xyz;
#else
    if (v_ditheringAndMaskTinting.y > 0.5) {
        diffuse.xyz = mix(diffuse.xyz, diffuse.xyz * v_color0.xyz, diffuse.w) * v_color0.w;
        diffuse.w = 1.0;
    } else {
        diffuse.xyz *= v_color0.xyz;
#if defined(OPAQUE_PASS)
        diffuse.w = v_color0.w;
#else
        diffuse.w *= v_color0.w;
#endif
    }
#endif
#endif

    // ---- luz do ambiente (bem fraca) ----
    vec3 lightmap = texture2D(s_LightMapTexture, v_lightmapUV).xyz;

    // ---- lanterna: cone saindo do centro da camera ----
    float dist = length(v_viewPos);
    float depthAlong = max(abs(v_viewPos.z), 0.0001);
    float tanAngle = length(v_viewPos.xy) / depthAlong;
    float cone = 1.0 - smoothstep(CONE_INNER, CONE_OUTER, tanAngle);
    float reach = clamp(1.0 - dist / BEAM_RANGE, 0.0, 1.0);
    float beam = cone * reach * reach;

    // tremida leve da luz
    float t = ViewPositionAndTime.w;
    float flicker = 1.0 - 0.06 * sin(t * 29.0) * sin(t * 7.3);

    vec3 light = lightmap * AMBIENT + vec3(1.0, 0.93, 0.78) * (beam * BEAM_POWER * flicker);
    vec3 lit = diffuse.xyz * light;

    // dessaturar
    float grey = dot(lit, vec3(0.299, 0.587, 0.114));
    lit = mix(vec3_splat(grey), lit, SATURATION);

    // neblina escura no lugar da neblina normal
    gl_FragColor = vec4(mix(lit, FOG_DARK, v_fog.w), diffuse.w);
}

#endif
