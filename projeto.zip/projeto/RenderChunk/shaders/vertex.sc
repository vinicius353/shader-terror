$input a_position
#if !defined(DEPTH_ONLY_OPAQUE_PASS) && !defined(DEPTH_ONLY_ALPHA_TEST_PASS)
$input a_color0, a_texcoord0, a_texcoord1
#else
#ifdef RENDER_AS_BILLBOARDS__ON
$input a_color0
#endif
#ifdef DEPTH_ONLY_ALPHA_TEST_PASS
$input a_texcoord0
#endif
#endif
#ifdef INSTANCING__ON
$input i_data1, i_data2, i_data3
#endif
#if !defined(DEPTH_ONLY_OPAQUE_PASS) && !defined(DEPTH_ONLY_ALPHA_TEST_PASS)
$output v_color0, v_fog, v_lightmapUV, v_texcoord0, v_ditheringAndMaskTinting, v_viewPos
#else
$output v_texcoord0
#endif

#include <bgfx_shader.sh>

uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;
uniform vec4 MeshContext;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 SubPixelOffset;
uniform vec4 ViewPositionAndTime;

void main() {
    // ---- posicao no mundo (mesma logica do shader original) ----
    mat4 model;
#ifdef INSTANCING__ON
    model[0] = vec4(i_data1.x, i_data2.x, i_data3.x, 0.0);
    model[1] = vec4(i_data1.y, i_data2.y, i_data3.y, 0.0);
    model[2] = vec4(i_data1.z, i_data2.z, i_data3.z, 0.0);
    model[3] = vec4(i_data1.w, i_data2.w, i_data3.w, 1.0);
#else
    model = u_model[0];
#endif
    vec3 worldPos = mul(model, vec4(a_position, 1.0)).xyz;

#ifdef RENDER_AS_BILLBOARDS__ON
    vec3 center = worldPos + vec3_splat(0.5);
    vec3 fwd = normalize(center - ViewPositionAndTime.xyz);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
    vec3 c = a_color0.xyz;
    worldPos = center - ((cross(fwd, right) * (c.z - 0.5)) + (right * (c.x - 0.5)));
#endif

    // ---- projecao com jitter sub-pixel ----
    mat4 proj = u_proj;
#if BGFX_SHADER_LANGUAGE_GLSL
    proj[2][0] += SubPixelOffset.x;
    proj[2][1] -= SubPixelOffset.y;
#else
    proj[0][2] += SubPixelOffset.x;
    proj[1][2] -= SubPixelOffset.y;
#endif
    vec4 viewPos4 = mul(u_view, vec4(worldPos, 1.0));
    gl_Position = mul(proj, viewPos4);

    // ---- passes so de profundidade ----
#if defined(DEPTH_ONLY_OPAQUE_PASS)
    v_texcoord0 = vec2_splat(0.0);
#elif defined(DEPTH_ONLY_ALPHA_TEST_PASS)
    uvec2 tcd = uvec2(round(a_texcoord0 * 65535.0));
    vec2 uvd = vec2(float((tcd.x & 32767u) << 1u), float((tcd.y & 32767u) << 1u)) * 1.52590219e-05;
    uvd.x += 3.0517578125e-05 * ((2.0 * float((tcd.x & 32768u) >> 15u)) - 1.0);
    uvd.y += 3.0517578125e-05 * ((2.0 * float((tcd.y & 32768u) >> 15u)) - 1.0);
    v_texcoord0 = uvd;
#else
    // ---- passes de cor ----
    uvec2 tc = uvec2(round(a_texcoord0 * 65535.0));
    vec2 uv = vec2(float((tc.x & 32767u) << 1u), float((tc.y & 32767u) << 1u)) * 1.52590219e-05;
    uv.x += 3.0517578125e-05 * ((2.0 * float((tc.x & 32768u) >> 15u)) - 1.0);
    uv.y += 3.0517578125e-05 * ((2.0 * float((tc.y & 32768u) >> 15u)) - 1.0);
    v_texcoord0 = uv;

    uvec2 lm = uvec2(round(a_texcoord1 * 65535.0));
    v_lightmapUV = vec2(uvec2(lm.y >> 4u, lm.y) & uvec2(15u, 15u)) * 0.06666667;
    v_ditheringAndMaskTinting = vec2(notEqual((lm & uvec2(256u, 256u)), uvec2(0u, 0u)));

#ifdef RENDER_AS_BILLBOARDS__ON
    v_color0 = vec4_splat(1.0);
#else
    v_color0 = a_color0;
#endif

    vec4 fogCtrl = mix(FogAndDistanceControl, vec4(0.99, 1.0, 100000.0, 100000.0), bvec4(MeshContext.x > 0.5));
    float fogAmount = clamp((((length(ViewPositionAndTime.xyz - worldPos) / fogCtrl.z) + RenderChunkFogAlpha.x) - fogCtrl.x) / (fogCtrl.y - fogCtrl.x), 0.0, 1.0);
    v_fog = vec4(FogColor.xyz, fogAmount);

    // posicao no espaco da camera (usada pela lanterna no fragment)
    v_viewPos = viewPos4.xyz;
#endif
}
