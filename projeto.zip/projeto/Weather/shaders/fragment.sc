#if defined(TRANSPARENT_PASS)
$input v_fog
$input v_occlusionHeight
$input v_occlusionUV
$input v_texcoord0
$input v_viewPos
#endif

#include <bgfx_shader.sh>
#define H_AMBIENT_OVERRIDE 0.10
#include <horror.sh>

#if defined(TRANSPARENT_PASS)
SAMPLER2D(s_LightingTexture, s_LightingTexture_REG);
SAMPLER2D(s_OcclusionTexture, s_OcclusionTexture_REG);
SAMPLER2D(s_WeatherTexture, s_WeatherTexture_REG);
uniform vec4 OcclusionHeightOffset;
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
void func_5336b(inout uvec4 arg_a0805, inout vec2 arg_31df6) {
    float loc_519df = float(arg_a0805.z & 15u) * 0.066666670143604278564453125;
    float loc_1d09f = (float((arg_a0805.x | (arg_a0805.y << 8u)) & 1023u) + OcclusionHeightOffset.x) * 0.0039215688593685626983642578125;
    bool loc_47b39 = v_occlusionUV.x >= 0.0;
    bool loc_77737;
    if (loc_47b39)
    {
        loc_77737 = v_occlusionUV.x <= 1.0;
    }
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
loc_77737 = loc_47b39;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
bool loc_8f253;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
if (loc_77737)
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
loc_8f253 = v_occlusionUV.y >= 0.0;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
loc_8f253 = loc_77737;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
bool loc_1a0b7;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
if (loc_8f253)
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
loc_1a0b7 = v_occlusionUV.y <= 1.0;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
loc_1a0b7 = loc_8f253;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
if (loc_1a0b7 && (v_occlusionHeight < loc_1d09f))
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
arg_31df6 = vec2(0.0);
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
return;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
arg_31df6 = vec2(loc_519df - (clamp((v_occlusionHeight - loc_1d09f) * 25.0, 0.0, 1.0) * loc_519df), 1.0);
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
return;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
}
#endif
#ifdef NO_OCCLUSION__ON
void func_0e12e(inout uvec4 arg_adc9f, inout vec2 arg_a9ce0) {
    float loc_9a9ec = float(arg_adc9f.z & 15u) * 0.066666670143604278564453125;
    arg_a9ce0 = vec2(loc_9a9ec - (clamp((v_occlusionHeight - ((float((arg_adc9f.x | (arg_adc9f.y << 8u)) & 1023u) + OcclusionHeightOffset.x) * 0.0039215688593685626983642578125)) * 25.0, 0.0, 1.0) * loc_9a9ec), 1.0);
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
void func_398ee(inout uvec4 arg_a0805, inout vec2 arg_31df6) {
    float loc_519df = float(arg_a0805.z & 15u) * 0.066666670143604278564453125;
    float loc_a6050 = (float((arg_a0805.x | (arg_a0805.y << 8u)) & 1023u) + OcclusionHeightOffset.x) * 0.0039215688593685626983642578125;
    bool loc_47b39 = v_occlusionUV.x >= 0.0;
    bool loc_77737;
    if (loc_47b39)
    {
        loc_77737 = v_occlusionUV.x <= 1.0;
    }
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
loc_77737 = loc_47b39;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
bool loc_8f253;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
if (loc_77737)
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
loc_8f253 = v_occlusionUV.y >= 0.0;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
loc_8f253 = loc_77737;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
bool loc_65342;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
if (loc_8f253)
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
loc_65342 = v_occlusionUV.y <= 1.0;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
loc_65342 = loc_8f253;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
if (loc_65342 && (v_occlusionHeight > loc_a6050))
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
arg_31df6 = vec2(0.0);
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
return;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
else
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
{
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
arg_31df6 = vec2(loc_519df - (clamp((v_occlusionHeight - loc_a6050) * 25.0, 0.0, 1.0) * loc_519df), 1.0);
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
return;
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
}
#endif

void main() {
#ifdef NO_OCCLUSION__ON
    vec2 var_17770;
#endif
    vec4 var_59f74 = texture2D(s_WeatherTexture, v_texcoord0);
    vec4 var_e5cb6 = texture2D(s_OcclusionTexture, v_occlusionUV);
    uvec4 var_14d49 = uvec4(round(var_e5cb6 * 255.0));
#ifdef NO_OCCLUSION__OFF
    vec2 var_17770;
#endif
#if defined(FLIP_OCCLUSION__OFF) && defined(NO_OCCLUSION__OFF)
    func_5336b(var_14d49, var_17770);
#endif
#ifdef NO_OCCLUSION__ON
    func_0e12e(var_14d49, var_17770);
#endif
#if defined(FLIP_OCCLUSION__ON) && defined(NO_OCCLUSION__OFF)
    func_398ee(var_14d49, var_17770);
#endif
    vec2 var_cbd4c = var_17770;
    vec4 var_66861 = var_59f74;
    vec3 var_76a3f = var_66861.xyz * texture2D(s_LightingTexture, var_17770).xyz;
    var_59f74 = vec4(var_76a3f.x, var_76a3f.y, var_76a3f.z, var_66861.w);
    float var_eb925 = var_59f74.w * var_cbd4c.y;
    vec4 var_c0e46 = v_fog;
    {
        vec4 ___fc1 = vec4(mix(vec4(var_76a3f, var_eb925).xyz, v_fog.xyz, vec3(var_c0e46.w)), var_eb925);
        ___fc1.xyz = horrorApply(___fc1.xyz, v_fog.xyz, v_viewPos, vec3_splat(1.0));
        gl_FragColor = ___fc1;
    }
}

#endif
