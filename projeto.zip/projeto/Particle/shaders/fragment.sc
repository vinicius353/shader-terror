#if defined(ALPHA_TEST_PASS)
$input v_color0
$input v_fog
$input v_texcoord0
$input v_viewPos
#elif defined(TRANSPARENT_PASS)
$input v_color0
$input v_fog
$input v_texcoord0
$input v_viewPos
#endif

#include <bgfx_shader.sh>
#define H_AMBIENT_OVERRIDE 0.10
#include <horror.sh>

#if defined(ALPHA_TEST_PASS)
SAMPLER2D(s_ParticleTexture, s_ParticleTexture_REG);

void main() {
    vec4 var_f89cb = v_color0;
    vec4 var_e9859 = texture2D(s_ParticleTexture, v_texcoord0);
    if (var_e9859.w < 0.5)
    {
        discard;
    }
    var_e9859 *= vec4(v_color0.xyz, var_f89cb.w);
    var_e9859.w = 1.0;
    vec4 var_f6e07 = v_fog;
    {
        vec4 ___fc1 = vec4(mix(vec4(var_e9859.xyz, var_e9859.w).xyz, v_fog.xyz, vec3(var_f6e07.w)), var_e9859.w);
        ___fc1.xyz = horrorApply(___fc1.xyz, v_fog.xyz, v_viewPos, vec3_splat(1.0));
        gl_FragColor = ___fc1;
    }
}

#elif defined(TRANSPARENT_PASS)
SAMPLER2D(s_ParticleTexture, s_ParticleTexture_REG);

void main() {
    vec4 var_e966b = v_color0;
    vec4 var_6ca24 = v_fog;
    vec4 var_de643 = texture2D(s_ParticleTexture, v_texcoord0) * vec4(v_color0.xyz, var_e966b.w);
    vec3 var_97f02 = mix(var_de643.xyz, v_fog.xyz, vec3(var_6ca24.w));
    vec4 var_1146b = vec4(var_97f02.x, var_97f02.y, var_97f02.z, var_de643.w);
    vec4 var_eb888 = v_fog;
    {
        vec4 ___fc2 = vec4(mix(vec4(var_97f02, var_1146b.w).xyz, v_fog.xyz, vec3(var_eb888.w)), var_1146b.w);
        ___fc2.xyz = horrorApply(___fc2.xyz, v_fog.xyz, v_viewPos, vec3_splat(1.0));
        gl_FragColor = ___fc2;
    }
}

#endif
