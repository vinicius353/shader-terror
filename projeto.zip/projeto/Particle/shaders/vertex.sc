#if defined(ALPHA_TEST_PASS)
$input a_color0
$input a_position
$input a_texcoord0
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_color0
$output v_fog
$output v_texcoord0
$output v_worldPos
$output v_viewPos
#elif defined(TRANSPARENT_PASS)
$input a_color0
$input a_position
$input a_texcoord0
#ifdef INSTANCING__ON
$input i_data1
#endif
#ifdef INSTANCING__ON
$input i_data2
#endif
#ifdef INSTANCING__ON
$input i_data3
#endif
$output v_color0
$output v_fog
$output v_texcoord0
$output v_worldPos
$output v_viewPos
#endif

#include <bgfx_shader.sh>
#include <horror.sh>

#if defined(ALPHA_TEST_PASS)
uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;

void main() {
#ifdef INSTANCING__OFF
    vec4 var_12727 = u_model[0] * vec4(a_position, 1.0);
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_e43a8;
    var_e43a8[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_e43a8[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_e43a8[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_e43a8[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
    vec4 var_12727 = var_e43a8 * vec4(a_position, 1.0);
#endif
    vec4 var_32522 = u_viewProj * vec4(var_12727.xyz, 1.0);
    vec4 var_b4024 = var_32522;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_b4024.z / FogAndDistanceControl.z) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_texcoord0 = a_texcoord0;
    v_worldPos = var_12727.xyz;
    vec4 ___cp1 = var_32522;
    gl_Position = ___cp1;
    v_viewPos = vec3(___cp1.xy / vec2(u_proj[0][0], u_proj[1][1]), ___cp1.w);
}

#elif defined(TRANSPARENT_PASS)
uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;

void main() {
#ifdef INSTANCING__OFF
    vec4 var_12727 = u_model[0] * vec4(a_position, 1.0);
#endif
#ifdef INSTANCING__ON
    vec4 var_78b44 = i_data1;
    vec4 var_e67a8 = i_data2;
    vec4 var_1b7f0 = i_data3;
    mat4 var_e43a8;
    var_e43a8[0] = vec4(var_78b44.x, var_e67a8.x, var_1b7f0.x, 0.0);
    var_e43a8[1] = vec4(var_78b44.y, var_e67a8.y, var_1b7f0.y, 0.0);
    var_e43a8[2] = vec4(var_78b44.z, var_e67a8.z, var_1b7f0.z, 0.0);
    var_e43a8[3] = vec4(var_78b44.w, var_e67a8.w, var_1b7f0.w, 1.0);
    vec4 var_12727 = var_e43a8 * vec4(a_position, 1.0);
#endif
    vec4 var_32522 = u_viewProj * vec4(var_12727.xyz, 1.0);
    vec4 var_b4024 = var_32522;
    v_color0 = a_color0;
    v_fog = vec4(FogColor.xyz, clamp(((var_b4024.z / FogAndDistanceControl.z) - FogAndDistanceControl.x) / (FogAndDistanceControl.y - FogAndDistanceControl.x), 0.0, 1.0));
    v_texcoord0 = a_texcoord0;
    v_worldPos = var_12727.xyz;
    vec4 ___cp2 = var_32522;
    gl_Position = ___cp2;
    v_viewPos = vec3(___cp2.xy / vec2(u_proj[0][0], u_proj[1][1]), ___cp2.w);
}

#endif
