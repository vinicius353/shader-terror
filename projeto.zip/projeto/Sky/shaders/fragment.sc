$input v_color0

#include <bgfx_shader.sh>

// Quanto do ceu original aparece (0 = preto total)
#define SKY_DARKEN 0.03

void main() {
    gl_FragColor = vec4(v_color0.xyz * SKY_DARKEN, v_color0.w);
}
