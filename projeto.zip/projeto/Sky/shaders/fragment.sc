$input v_color0, v_texcoord0

#include <bgfx_shader.sh>
#include <horror.sh>

void main() {
    float darken = mix(1.0, H_SKY_DARKEN, v_texcoord0.x);
    gl_FragColor = vec4(v_color0.xyz * darken, v_color0.w);
}
